import React, { useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { ActionButton, BrandMark, Metric, NeonCard, ScreenHeader } from '@/components/Ui';

type Preset = { name: string; tag: string; description: string; fps: string; latency: string; color: string };
const presets: Preset[] = [
  { name: 'COMPETITIVE', tag: 'LOW LATENCY', description: 'Responsif untuk ranked dan perangkat yang fokus ke stabilitas.', fps: '60 FPS', latency: 'Low', color: '#39B7FF' },
  { name: 'BALANCED', tag: 'RECOMMENDED', description: 'Keseimbangan visual, suhu, dan baterai untuk sesi panjang.', fps: '60 FPS', latency: 'Stable', color: '#58D6A5' },
  { name: 'ENDURANCE', tag: 'COOL DEVICE', description: 'Kurangi beban visual agar perangkat tetap nyaman lebih lama.', fps: '45 FPS', latency: 'Cool', color: '#FF9D55' },
];

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [activePreset, setActivePreset] = useState(1);
  const [applied, setApplied] = useState(false);

  const choosePreset = (index: number) => {
    setActivePreset(index);
    setApplied(false);
    Haptics.selectionAsync();
  };

  const applyPreset = () => {
    setApplied(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const openFreeFire = async () => {
    const candidates = ['freefiremax://', 'freefire://'];
    for (const url of candidates) {
      try {
        if (await Linking.canOpenURL(url)) {
          await Linking.openURL(url);
          return;
        }
      } catch {
        // Try the next known scheme.
      }
    }
    Alert.alert('Free Fire belum ditemukan', 'Pasang dan login melalui aplikasi Free Fire resmi, lalu kembali ke RLA X WARE. Aplikasi ini tidak melewati Play Store atau membypass autentikasi.');
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 16 }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 110 }]} showsVerticalScrollIndicator={false}>
        <ScreenHeader eyebrow="PERFORMANCE COMPANION" title="Main lebih fokus." subtitle="Profil perangkat yang jujur, kalkulator yang presisi, dan satu tombol untuk membuka game resmi." />

        <NeonCard accent style={styles.hero}>
          <View style={styles.heroGlow} />
          <View style={styles.heroTop}>
            <View>
              <Text style={[styles.cardKicker, { color: colors.primary }]}>CURRENT PROFILE</Text>
              <Text style={[styles.heroTitle, { color: colors.foreground }]}>{presets[activePreset].name}</Text>
              <Text style={[styles.heroCopy, { color: colors.mutedForeground }]}>{presets[activePreset].description}</Text>
            </View>
            <BrandMark />
          </View>
          <View style={styles.metricRow}>
            <Metric label="TARGET" value={presets[activePreset].fps} detail="STABLE" />
            <View style={{ width: 10 }} />
            <Metric label="RESPONSE" value={presets[activePreset].latency} detail="PROFILE" />
          </View>
          <View style={styles.heroAction}>
            <ActionButton label={applied ? 'PROFILE APPLIED' : 'APPLY PROFILE'} icon={applied ? 'check' : 'zap'} onPress={applyPreset} />
          </View>
          <Text style={[styles.microcopy, { color: colors.mutedForeground }]}>Profil hanya mengatur rekomendasi di aplikasi. Android menentukan perubahan sistem yang tersedia pada perangkatmu.</Text>
        </NeonCard>

        <View style={styles.sectionHeading}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Performance preset</Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground }]}>Pilih sesuai gaya bermain</Text>
        </View>
        <View style={styles.presetList}>
          {presets.map((preset, index) => {
            const selected = index === activePreset;
            return (
              <Pressable key={preset.name} testID={`preset-${preset.name}`} onPress={() => choosePreset(index)} style={[styles.preset, { backgroundColor: selected ? colors.secondary : colors.card, borderColor: selected ? preset.color : colors.border }]}>
                <View style={[styles.presetBar, { backgroundColor: preset.color }]} />
                <View style={styles.presetText}>
                  <View style={styles.presetNameRow}>
                    <Text style={[styles.presetName, { color: colors.foreground }]}>{preset.name}</Text>
                    <Text style={[styles.presetTag, { color: preset.color }]}>{preset.tag}</Text>
                  </View>
                  <Text style={[styles.presetDesc, { color: colors.mutedForeground }]}>{preset.description}</Text>
                </View>
                <Feather name={selected ? 'check-circle' : 'circle'} size={20} color={selected ? preset.color : colors.mutedForeground} />
              </Pressable>
            );
          })}
        </View>

        <NeonCard style={styles.launchCard}>
          <View style={styles.launchIcon}><Feather name="play" size={19} color={colors.accent} /></View>
          <View style={styles.launchText}>
            <Text style={[styles.launchTitle, { color: colors.foreground }]}>Game launch</Text>
            <Text style={[styles.launchCopy, { color: colors.mutedForeground }]}>Buka Free Fire Max / biasa yang sudah terpasang.</Text>
          </View>
          <Pressable testID="button-open-free-fire" onPress={openFreeFire} style={({ pressed }) => [styles.circleButton, { backgroundColor: colors.accent, opacity: pressed ? 0.72 : 1 }]}>
            <Feather name="arrow-up-right" size={18} color={colors.accentForeground} />
          </Pressable>
        </NeonCard>

        <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>RLA X WARE tidak mengubah file game, tidak menyuntikkan overlay ke permainan, dan tidak membypass login. Gunakan hanya aplikasi resmi.</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18 },
  hero: { marginBottom: 25 },
  heroGlow: { position: 'absolute', width: 190, height: 190, borderRadius: 95, backgroundColor: 'rgba(45,156,255,0.08)', top: -85, right: -55 },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  cardKicker: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.8, marginBottom: 7 },
  heroTitle: { fontFamily: 'Inter_700Bold', fontSize: 27, letterSpacing: -0.5 },
  heroCopy: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 19, maxWidth: 245, marginTop: 7 },
  metricRow: { flexDirection: 'row', marginTop: 20 },
  heroAction: { marginTop: 16 },
  microcopy: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, marginTop: 12 },
  sectionHeading: { marginBottom: 12 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  sectionHint: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 3 },
  presetList: { gap: 10, marginBottom: 18 },
  preset: { minHeight: 79, borderRadius: 17, borderWidth: 1, flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12, overflow: 'hidden' },
  presetBar: { width: 3, height: 43, borderRadius: 2 },
  presetText: { flex: 1 },
  presetNameRow: { flexDirection: 'row', alignItems: 'center', gap: 9, flexWrap: 'wrap' },
  presetName: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  presetTag: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.7 },
  presetDesc: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 5 },
  launchCard: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  launchIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: 'rgba(255,106,42,0.12)', alignItems: 'center', justifyContent: 'center' },
  launchText: { flex: 1 },
  launchTitle: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  launchCopy: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  circleButton: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  disclaimer: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15, paddingHorizontal: 10, marginBottom: 6 },
});