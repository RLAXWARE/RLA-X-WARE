import React, { useMemo, useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { ActionButton, NeonCard, ScreenHeader } from '@/components/Ui';

const scales = [48, 60, 85, 94, 100];

export default function ToolsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [width, setWidth] = useState('1080');
  const [height, setHeight] = useState('2400');
  const [scale, setScale] = useState(85);
  const [sensitivity, setSensitivity] = useState('92');
  const [buttons, setButtons] = useState('4');
  const [saved, setSaved] = useState(false);

  const resolution = useMemo(() => {
    const w = Number(width) || 0;
    const h = Number(height) || 0;
    const factor = scale / 100;
    return { w: Math.max(1, Math.round(w * factor)), h: Math.max(1, Math.round(h * factor)), dpi: Math.max(120, Math.round(420 * factor)) };
  }, [width, height, scale]);

  const hud = useMemo(() => {
    const s = Math.min(100, Math.max(1, Number(sensitivity) || 1));
    const count = Math.min(8, Math.max(2, Number(buttons) || 2));
    return { touch: Math.round(32 + s * 0.28), spacing: Math.round(10 + count * 1.5), recommended: count <= 4 ? 'Claw 3-finger' : 'Claw 4-finger' };
  }, [sensitivity, buttons]);

  const openDisplaySettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      Alert.alert('Izin belum tersedia', 'Buka Pengaturan Android secara manual, lalu cari akses tampilan atau pengaturan aplikasi.');
    }
  };

  const saveProfile = () => {
    setSaved(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 16 }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 110 }]} showsVerticalScrollIndicator={false}>
        <ScreenHeader eyebrow="DEVICE TOOLKIT" title="Kontrol yang terukur." subtitle="Hitung target dari resolusi asli perangkat. Tidak ada klaim palsu dan tidak ada edit sistem tanpa persetujuanmu." />

        <NeonCard accent style={styles.toolCard}>
          <View style={styles.toolTitleRow}>
            <View style={[styles.toolIcon, { backgroundColor: 'rgba(45,156,255,0.15)' }]}><Feather name="maximize" size={18} color={colors.primary} /></View>
            <View style={styles.toolTitleText}><Text style={[styles.toolTitle, { color: colors.foreground }]}>Resolution calculator</Text><Text style={[styles.toolSub, { color: colors.mutedForeground }]}>Target otomatis, tanpa edit manual</Text></View>
          </View>
          <View style={styles.inputRow}>
            <Field label="WIDTH" value={width} onChange={setWidth} colors={colors} />
            <Text style={[styles.multiply, { color: colors.mutedForeground }]}>×</Text>
            <Field label="HEIGHT" value={height} onChange={setHeight} colors={colors} />
          </View>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>PACKAGE SCALE</Text>
          <View style={styles.scaleRow}>
            {scales.map((item) => <Pressable key={item} testID={`scale-${item}`} onPress={() => { setScale(item); setSaved(false); Haptics.selectionAsync(); }} style={[styles.scale, { backgroundColor: scale === item ? colors.primary : colors.secondary, borderColor: scale === item ? colors.primary : colors.border }]}><Text style={[styles.scaleText, { color: scale === item ? colors.primaryForeground : colors.secondaryForeground }]}>{item}%</Text></Pressable>)}
          </View>
          <View style={[styles.result, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
            <View><Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>TARGET RESOLUTION</Text><Text style={[styles.resultValue, { color: colors.foreground }]}>{resolution.w} × {resolution.h}</Text></View>
            <View style={styles.resultRight}><Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>DENSITY</Text><Text style={[styles.resultValue, { color: colors.primary }]}>{resolution.dpi} dpi</Text></View>
          </View>
          <ActionButton label={saved ? 'PROFILE SAVED' : 'SAVE DEVICE PROFILE'} icon={saved ? 'check' : 'save'} onPress={saveProfile} />
        </NeonCard>

        <NeonCard style={styles.toolCard}>
          <View style={styles.toolTitleRow}>
            <View style={[styles.toolIcon, { backgroundColor: 'rgba(255,106,42,0.14)' }]}><Feather name="crosshair" size={18} color={colors.accent} /></View>
            <View style={styles.toolTitleText}><Text style={[styles.toolTitle, { color: colors.foreground }]}>HUD calculator</Text><Text style={[styles.toolSub, { color: colors.mutedForeground }]}>Layout assist untuk sentuhan konsisten</Text></View>
          </View>
          <View style={styles.inputRow}><Field label="SENSITIVITY" value={sensitivity} onChange={setSensitivity} colors={colors} /><Field label="BUTTONS" value={buttons} onChange={setButtons} colors={colors} /></View>
          <View style={[styles.hudResult, { borderColor: colors.border }]}>
            <View><Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>TOUCH SIZE</Text><Text style={[styles.hudValue, { color: colors.foreground }]}>{hud.touch} dp</Text></View>
            <View><Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>SPACING</Text><Text style={[styles.hudValue, { color: colors.foreground }]}>{hud.spacing} dp</Text></View>
            <View><Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>STYLE</Text><Text style={[styles.hudValue, { color: colors.accent }]}>{hud.recommended}</Text></View>
          </View>
          <Text style={[styles.microcopy, { color: colors.mutedForeground }]}>Gunakan angka ini sebagai panduan saat mengatur HUD di dalam game secara manual.</Text>
        </NeonCard>

        <NeonCard style={styles.permissionCard}>
          <View style={styles.permissionCopy}><Text style={[styles.toolTitle, { color: colors.foreground }]}>Android permissions</Text><Text style={[styles.toolSub, { color: colors.mutedForeground }]}>Perubahan resolusi sistem memerlukan izin Android resmi dan dukungan vendor. Kami hanya membuka pengaturan, tidak memaksa.</Text></View>
          <Pressable testID="button-open-settings" onPress={openDisplaySettings} style={({ pressed }) => [styles.settingsButton, { borderColor: colors.border, backgroundColor: colors.secondary, opacity: pressed ? 0.75 : 1 }]}><Feather name="settings" size={17} color={colors.primary} /></Pressable>
        </NeonCard>
      </ScrollView>
    </View>
  );
}

function Field({ label, value, onChange, colors }: { label: string; value: string; onChange: (value: string) => void; colors: ReturnType<typeof useColors> }) {
  return <View style={styles.field}><Text style={[styles.label, { color: colors.mutedForeground }]}>{label}</Text><TextInput testID={`input-${label.toLowerCase()}`} value={value} onChangeText={(next) => onChange(next.replace(/[^0-9]/g, ''))} keyboardType="number-pad" style={[styles.input, { color: colors.foreground, backgroundColor: colors.secondary, borderColor: colors.border }]} /></View>;
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18 },
  toolCard: { marginBottom: 14, gap: 15 },
  toolTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  toolIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  toolTitleText: { flex: 1 },
  toolTitle: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  toolSub: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 9 },
  field: { flex: 1, gap: 6 },
  label: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.2 },
  input: { height: 45, borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  multiply: { paddingBottom: 13, fontFamily: 'Inter_700Bold', fontSize: 14 },
  scaleRow: { flexDirection: 'row', gap: 6 },
  scale: { flex: 1, height: 34, borderWidth: 1, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  scaleText: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  result: { borderWidth: 1, borderRadius: 14, padding: 13, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  resultRight: { alignItems: 'flex-end' },
  resultLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1 },
  resultValue: { fontFamily: 'Inter_700Bold', fontSize: 17, marginTop: 5 },
  hudResult: { borderWidth: 1, borderRadius: 14, padding: 13, flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  hudValue: { fontFamily: 'Inter_700Bold', fontSize: 13, marginTop: 6 },
  microcopy: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  permissionCard: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  permissionCopy: { flex: 1, gap: 3 },
  settingsButton: { width: 42, height: 42, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
});