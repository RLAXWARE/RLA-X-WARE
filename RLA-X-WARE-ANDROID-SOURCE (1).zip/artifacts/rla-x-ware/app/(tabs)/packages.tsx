import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { ActionButton, NeonCard, ScreenHeader } from '@/components/Ui';

const packages = [
  { percent: 48, title: 'STARTER', price: 'Rp19.000', note: 'Untuk mulai rapi', color: '#6AAFFF', features: ['Preset Basic', 'Resolution calculator', 'HUD guide'] },
  { percent: 60, title: 'CORE', price: 'Rp29.000', note: 'Paling seimbang', color: '#58D6A5', features: ['Preset Balanced', 'Density calculator', 'HUD guide'] },
  { percent: 85, title: 'PRO', price: 'Rp49.000', note: 'Pilihan populer', color: '#FF9D55', features: ['Semua preset', 'Profile tersimpan', 'Priority tips'] },
  { percent: 94, title: 'ELITE', price: 'Rp69.000', note: 'Untuk perangkat premium', color: '#C99BFF', features: ['Advanced profile', 'Custom HUD notes', 'Priority setup'] },
  { percent: 100, title: 'MAX', price: 'Rp89.000', note: 'Paket lengkap', color: '#FF6A88', features: ['Semua fitur', 'Multi-device notes', 'Premium support'] },
];

export default function PackagesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [selected, setSelected] = useState(2);
  const [requested, setRequested] = useState(false);
  const current = packages[selected];

  const select = (index: number) => {
    setSelected(index);
    setRequested(false);
    Haptics.selectionAsync();
  };

  const request = () => {
    setRequested(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert('Paket dipilih', `${current.title} ${current.percent}% sudah ditandai. Hubungi admin resmi untuk pembayaran dan aktivasi.`);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop: insets.top + 16 }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 110 }]} showsVerticalScrollIndicator={false}>
        <ScreenHeader eyebrow="CUSTOMER ACCESS" title="Pilih paketmu." subtitle="Harga transparan untuk profil dan panduan. Pembayaran tidak dilakukan otomatis di dalam aplikasi ini." />
        <View style={styles.stack}>
          {packages.map((item, index) => {
            const active = selected === index;
            return (
              <Pressable key={item.percent} testID={`package-${item.percent}`} onPress={() => select(index)} style={[styles.package, { backgroundColor: active ? colors.secondary : colors.card, borderColor: active ? item.color : colors.border }]}>
                <View style={[styles.percentBlock, { backgroundColor: `${item.color}1A` }]}><Text style={[styles.percent, { color: item.color }]}>{item.percent}%</Text><Text style={[styles.percentLabel, { color: colors.mutedForeground }]}>PROFILE</Text></View>
                <View style={styles.packageMain}><View style={styles.packageTitleRow}><Text style={[styles.packageTitle, { color: colors.foreground }]}>{item.title}</Text>{active && <View style={[styles.selectedBadge, { backgroundColor: item.color }]}><Text style={[styles.selectedText, { color: colors.background }]}>SELECTED</Text></View>}</View><Text style={[styles.packageNote, { color: colors.mutedForeground }]}>{item.note}</Text><View style={styles.featureLine}>{item.features.map((feature) => <View key={feature} style={styles.feature}><Feather name="check" size={11} color={item.color} /><Text style={[styles.featureText, { color: colors.mutedForeground }]}>{feature}</Text></View>)}</View></View>
                <Text style={[styles.price, { color: colors.foreground }]}>{item.price}</Text>
              </Pressable>
            );
          })}
        </View>
        <NeonCard accent style={styles.summary}>
          <View><Text style={[styles.summaryLabel, { color: colors.primary }]}>YOUR SELECTION</Text><Text style={[styles.summaryTitle, { color: colors.foreground }]}>{current.title} · {current.percent}%</Text><Text style={[styles.summaryPrice, { color: colors.mutedForeground }]}>{current.price} · aktivasi manual oleh admin</Text></View>
          <ActionButton label={requested ? 'REQUESTED' : 'PILIH PAKET'} icon={requested ? 'check' : 'arrow-right'} onPress={request} />
        </NeonCard>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18 },
  stack: { gap: 10, marginBottom: 16 },
  package: { borderRadius: 17, borderWidth: 1, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 11, minHeight: 104 },
  percentBlock: { width: 63, height: 73, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  percent: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  percentLabel: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 1, marginTop: 3 },
  packageMain: { flex: 1, minWidth: 0 },
  packageTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' },
  packageTitle: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  selectedBadge: { borderRadius: 5, paddingHorizontal: 6, paddingVertical: 3 },
  selectedText: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.5 },
  packageNote: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 2 },
  featureLine: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 9 },
  feature: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  featureText: { fontFamily: 'Inter_500Medium', fontSize: 9 },
  price: { fontFamily: 'Inter_700Bold', fontSize: 13, alignSelf: 'flex-start', marginTop: 4 },
  summary: { gap: 14 },
  summaryLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.5 },
  summaryTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, marginTop: 5 },
  summaryPrice: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 4 },
});