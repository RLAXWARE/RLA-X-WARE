import React, { PropsWithChildren } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';

export function BrandMark({ small = false }: { small?: boolean }) {
  const colors = useColors();
  return (
    <View style={[styles.mark, small && styles.markSmall, { borderColor: colors.primary }]}>
      <Feather name="zap" size={small ? 15 : 20} color={colors.primary} />
    </View>
  );
}

export function ScreenHeader({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  const colors = useColors();
  return (
    <View style={styles.header}>
      <View style={styles.headerRow}>
        <View style={styles.brandRow}>
          <BrandMark small />
          <Text style={[styles.brandName, { color: colors.foreground }]}>RLA X WARE</Text>
        </View>
        <View style={[styles.livePill, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
          <View style={[styles.liveDot, { backgroundColor: colors.accent }]} />
          <Text style={[styles.liveText, { color: colors.mutedForeground }]}>READY</Text>
        </View>
      </View>
      <Text style={[styles.eyebrow, { color: colors.primary }]}>{eyebrow.toUpperCase()}</Text>
      <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{subtitle}</Text>
    </View>
  );
}

export function NeonCard({ children, style, accent = false }: PropsWithChildren<{ style?: object; accent?: boolean }>) {
  const colors = useColors();
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: accent ? colors.primary : colors.border }, style]}>
      {accent && <LinearGradient colors={['rgba(45,156,255,0.16)', 'transparent']} style={StyleSheet.absoluteFill} />}
      {children}
    </View>
  );
}

export function ActionButton({ label, onPress, icon = 'arrow-up-right', secondary = false, disabled = false }: { label: string; onPress: () => void; icon?: keyof typeof Feather.glyphMap; secondary?: boolean; disabled?: boolean }) {
  const colors = useColors();
  return (
    <Pressable
      testID={`button-${label}`}
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.action,
        { backgroundColor: secondary ? colors.secondary : colors.primary, borderColor: secondary ? colors.border : colors.primary, opacity: disabled ? 0.45 : pressed ? 0.78 : 1 },
      ]}
    >
      <Text style={[styles.actionText, { color: secondary ? colors.secondaryForeground : colors.primaryForeground }]}>{label}</Text>
      <Feather name={icon} size={16} color={secondary ? colors.secondaryForeground : colors.primaryForeground} />
    </Pressable>
  );
}

export function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  const colors = useColors();
  return (
    <View style={[styles.metric, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
      <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.metricValue, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.metricDetail, { color: colors.primary }]}>{detail}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  mark: { width: 44, height: 44, borderRadius: 15, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0B1728' },
  markSmall: { width: 30, height: 30, borderRadius: 10 },
  header: { gap: 8, paddingBottom: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  brandName: { fontFamily: 'Inter_700Bold', letterSpacing: 1.2, fontSize: 13 },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 7, borderWidth: 1, borderRadius: 100, paddingHorizontal: 10, paddingVertical: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  liveText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.2 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 2 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, letterSpacing: -0.8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, maxWidth: 330 },
  card: { borderRadius: 20, borderWidth: 1, padding: 17, overflow: 'hidden' },
  action: { minHeight: 48, borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  actionText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  metric: { flex: 1, borderRadius: 16, borderWidth: 1, padding: 13, minHeight: 88 },
  metricLabel: { fontFamily: 'Inter_500Medium', fontSize: 11, marginBottom: 8 },
  metricValue: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  metricDetail: { fontFamily: 'Inter_600SemiBold', fontSize: 10, marginTop: 4 },
});