/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#F5F8FF',
    tint: '#39B7FF',
    background: '#060A12',
    foreground: '#F5F8FF',
    card: '#0D1422',
    cardForeground: '#F5F8FF',
    primary: '#2D9CFF',
    primaryForeground: '#04101D',
    secondary: '#111D31',
    secondaryForeground: '#D8E9FF',
    muted: '#172238',
    mutedForeground: '#8B9CB7',
    accent: '#FF6A2A',
    accentForeground: '#FFF2EA',
    destructive: '#F05E68',
    destructiveForeground: '#FFFFFF',
    border: '#1B2C46',
    input: '#15243A',
  },
  dark: {
    text: '#F5F8FF',
    tint: '#39B7FF',
    background: '#060A12',
    foreground: '#F5F8FF',
    card: '#0D1422',
    cardForeground: '#F5F8FF',
    primary: '#2D9CFF',
    primaryForeground: '#04101D',
    secondary: '#111D31',
    secondaryForeground: '#D8E9FF',
    muted: '#172238',
    mutedForeground: '#8B9CB7',
    accent: '#FF6A2A',
    accentForeground: '#FFF2EA',
    destructive: '#F05E68',
    destructiveForeground: '#FFFFFF',
    border: '#1B2C46',
    input: '#15243A',
  },
  radius: 18,
};

export default colors;
